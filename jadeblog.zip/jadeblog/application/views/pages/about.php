<h2><?= $title ?></h2>
<p> Clothing Store </p>