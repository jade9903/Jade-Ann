<h2><?= $title ?></h2>

<p style="color:white" style="text-align: justify"> "A young enterpreneur who works hard to achieve her goals in life." </p>


<p><h1  style="color:pink;"> Good Day! I'm Jade Ann Dotollo the owner of colette.ph_ </h1>

<h2  style="color: white"> We are selling branded overruns & rtw items. </h2></p>

<p><h3 style="text-align: center">  Please like and follow our social media accounts:  </p></h3>

<p><h4 style="text-align: center;">FB PAGE:COLETTE.PH_ </p></h4>

<p><h4 style="text-align: center;"> IG:COLETTE.PH_ </p></h4>

